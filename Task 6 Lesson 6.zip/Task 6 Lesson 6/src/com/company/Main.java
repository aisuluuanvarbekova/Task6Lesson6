package com.company;

public class Main {

    public static void main(String[] args) {
        Account <Integer> account = new Account<>(98765,5000);
        System.out.println(account.getSum());
        System.out.println(account.getId());


    }
}
