package com.company;

public interface Countable {
   public void saveMoney ();
}
